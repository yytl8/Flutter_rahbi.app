# 🪵 الرحبي للنجارة — نظام الإدارة v2.0

نظام إدارة متكامل لمحلات النجارة مبني بـ Flutter + Firebase

---

## 📦 المكتبات المستخدمة

| المكتبة | الإصدار | الاستخدام |
|---------|---------|----------|
| `firebase_core` | ^3.6.0 | Firebase الأساسية |
| `cloud_firestore` | ^5.4.3 | قاعدة البيانات |
| `flutter_riverpod` | ^2.6.1 | إدارة الحالة |
| `go_router` | ^14.3.0 | التنقل بين الشاشات |
| `flutter_animate` | ^4.5.0 | الأنيميشن |
| `fl_chart` | ^0.69.0 | الرسوم البيانية |
| `shimmer` | ^3.0.0 | تأثير التحميل |
| `gap` | ^3.0.1 | المسافات |
| `intl` | ^0.19.0 | تنسيق الأرقام والتواريخ |
| `shared_preferences` | ^2.3.2 | التخزين المحلي |
| `uuid` | ^4.5.1 | توليد المعرفات |
| `connectivity_plus` | ^6.1.0 | فحص الاتصال |

---

## 🚀 تشغيل المشروع

### المتطلبات
- Flutter SDK 3.19+
- Dart SDK 3.3+
- Android Studio / VS Code

### خطوات التشغيل

```bash
# 1. تثبيت المكتبات
flutter pub get

# 2. تشغيل التطبيق (debug)
flutter run

# 3. بناء APK للتوزيع
flutter build apk --release

# 4. بناء App Bundle (Google Play)
flutter build appbundle --release
```

### تشغيل على محاكي Android
```bash
# قائمة المحاكيات المتاحة
flutter emulators

# تشغيل المحاكي
flutter emulators --launch <emulator_id>

# ثم تشغيل التطبيق
flutter run
```

---

## 🗂️ هيكل المشروع

```
lib/
├── core/
│   ├── app_router.dart     # نظام التنقل (go_router)
│   ├── providers.dart      # مزودو البيانات (Riverpod)
│   └── theme.dart          # الثيم والألوان والمساعدات
├── models/
│   └── models.dart         # نماذج البيانات
├── screens/
│   ├── splash_screen.dart       # شاشة البداية
│   ├── auth_screen.dart         # تسجيل الدخول/التسجيل
│   ├── main_shell.dart          # Shell الرئيسي + NavigationBar
│   ├── dashboard_screen.dart    # لوحة التحكم مع رسوم بيانية
│   ├── clients_screen.dart      # العملاء
│   ├── workers_screen.dart      # العمال
│   ├── suppliers_screen.dart    # الموردون
│   ├── cashflow_screen.dart     # التدفق النقدي
│   ├── ai_analyzer_screen.dart  # محلل AI
│   ├── settings_screen.dart     # الإعدادات
│   └── worker_portal_screen.dart # بوابة العمال
└── widgets/
    └── common_widgets.dart   # مكونات مشتركة
```

---

## 🔥 إصلاحات v2.0

1. ✅ **إزالة تكرار class RahbiApp** في main.dart
2. ✅ **ترقية Firebase** من v2 إلى v3
3. ✅ **ترقية go_router** من 13 إلى 14
4. ✅ **Material 3 NavigationBar** بدلاً من BottomNavigationBar القديم
5. ✅ **رسوم بيانية** (PieChart) في الداشبورد
6. ✅ **Shimmer loading** بدلاً من loading بسيط
7. ✅ **إضافة CashflowEntry** للموديلز
8. ✅ **إصلاح cashflow_screen** - كانت تستخدم 'completed' بدل 'done'
9. ✅ **إصلاح router** - إزالة import لملف غير موجود (shop_select_screen)
10. ✅ **تحديث Android Gradle** من 8.1 إلى 8.3 + Kotlin 2.0
11. ✅ **minSdk 23** (بدلاً من 21 المتقادم)
12. ✅ **Java 17** بدلاً من Java 8
13. ✅ **textScaler.noScaling** لحماية التخطيط من إعدادات الخط
14. ✅ **AppShadows** - نظام ظلال موحد
15. ✅ **إضافة أنيميشن** flutter_animate في معظم الشاشات

---

## 🎨 الخطوط (اختياري)

لإضافة خطوط Cairo/Tajawal العربية:

1. حمّل الخطوط من [Google Fonts](https://fonts.google.com)
2. ضعها في `assets/fonts/`
3. أزل التعليق من قسم `fonts` في `pubspec.yaml`
4. شغّل `flutter pub get`

---

## 📱 Firebase Setup

تأكد أن ملف `lib/firebase_options.dart` يحتوي على بيانات مشروعك.
لإعادة الإعداد: `flutterfire configure`
