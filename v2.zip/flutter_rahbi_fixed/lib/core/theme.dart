import 'package:flutter/material.dart';

// ══════════════════════════════════════════
// 🎨 نظام الألوان
// ══════════════════════════════════════════
class AppColors {
  // Primary — Indigo
  static const Color primary = Color(0xFF4F46E5);
  static const Color primary2 = Color(0xFF3730A3);
  static const Color primary3 = Color(0xFF1E1B72);
  static const Color primaryLight = Color(0xFFEEF0FF);
  static const Color primaryPale = Color(0xFFC7D2FE);

  // Aliases for backward compat
  static const Color teal = primary;
  static const Color teal2 = primary2;
  static const Color teal3 = primary3;
  static const Color tealLight = primaryLight;
  static const Color tealPale = primaryPale;

  // Semantic
  static const Color gold = Color(0xFFD97706);
  static const Color goldLight = Color(0xFFFEF3C7);
  static const Color green = Color(0xFF059669);
  static const Color greenLight = Color(0xFFECFDF5);
  static const Color red = Color(0xFFDC2626);
  static const Color redLight = Color(0xFFFEF2F2);
  static const Color blue = Color(0xFF2563EB);
  static const Color blueLight = Color(0xFFEFF6FF);
  static const Color purple = Color(0xFF7C3AED);
  static const Color purpleLight = Color(0xFFF5F3FF);
  static const Color orange = Color(0xFFEA580C);
  static const Color orangeLight = Color(0xFFFFF7ED);

  // Backgrounds
  static const Color bg = Color(0xFFF0F2FA);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surface2 = Color(0xFFF7F8FD);
  static const Color surface3 = Color(0xFFEEF0FC);

  // Borders
  static const Color border = Color(0xFFDDE2F4);
  static const Color border2 = Color(0xFFC4CCE8);

  // Text
  static const Color text = Color(0xFF0F172A);
  static const Color text2 = Color(0xFF475569);
  static const Color text3 = Color(0xFF94A3B8);

  // Entity colors
  static const List<Color> entityColors = [
    Color(0xFF4F46E5),
    Color(0xFF059669),
    Color(0xFFD97706),
    Color(0xFFDC2626),
    Color(0xFF7C3AED),
    Color(0xFF2563EB),
    Color(0xFFEA580C),
    Color(0xFF0891B2),
  ];

  static Color entityColor(String id) {
    final hash = id.codeUnits.fold(0, (a, b) => a + b);
    return entityColors[hash % entityColors.length];
  }
}

// ══════════════════════════════════════════
// 📐 Border Radius & Spacing
// ══════════════════════════════════════════
class AppRadius {
  static const double xs = 8.0;
  static const double sm = 10.0;
  static const double md = 14.0;
  static const double lg = 20.0;
  static const double xl = 24.0;
  static const double xxl = 32.0;

  static BorderRadius get xsmall => BorderRadius.circular(xs);
  static BorderRadius get small => BorderRadius.circular(sm);
  static BorderRadius get medium => BorderRadius.circular(md);
  static BorderRadius get large => BorderRadius.circular(lg);
  static BorderRadius get xlarge => BorderRadius.circular(xl);
}

class AppSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 12.0;
  static const double lg = 16.0;
  static const double xl = 20.0;
  static const double xxl = 24.0;
  static const double xxxl = 32.0;
}

// ══════════════════════════════════════════
// 🔤 Text Styles
// ══════════════════════════════════════════
class AppTextStyles {
  static const TextStyle headline1 = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w800,
    color: AppColors.text,
    letterSpacing: -0.5,
    height: 1.2,
  );

  static const TextStyle headline2 = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w700,
    color: AppColors.text,
    letterSpacing: -0.3,
    height: 1.3,
  );

  static const TextStyle title = TextStyle(
    fontSize: 17,
    fontWeight: FontWeight.w700,
    color: AppColors.text,
    letterSpacing: -0.2,
  );

  static const TextStyle subtitle = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: AppColors.text,
  );

  static const TextStyle body = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: AppColors.text2,
    height: 1.5,
  );

  static const TextStyle caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: AppColors.text3,
  );

  static const TextStyle label = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w600,
    color: AppColors.text3,
    letterSpacing: 0.3,
  );

  static const TextStyle amount = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w800,
    color: AppColors.text,
    letterSpacing: -0.5,
  );
}

// ══════════════════════════════════════════
// 🌟 Box Shadows
// ══════════════════════════════════════════
class AppShadows {
  static List<BoxShadow> get sm => [
    BoxShadow(
      color: const Color(0xFF1E1B72).withOpacity(0.04),
      blurRadius: 8,
      offset: const Offset(0, 2),
    ),
  ];

  static List<BoxShadow> get md => [
    BoxShadow(
      color: const Color(0xFF1E1B72).withOpacity(0.06),
      blurRadius: 16,
      offset: const Offset(0, 4),
    ),
    BoxShadow(
      color: const Color(0xFF1E1B72).withOpacity(0.03),
      blurRadius: 4,
      offset: const Offset(0, 1),
    ),
  ];

  static List<BoxShadow> get lg => [
    BoxShadow(
      color: const Color(0xFF1E1B72).withOpacity(0.1),
      blurRadius: 32,
      offset: const Offset(0, 8),
    ),
    BoxShadow(
      color: const Color(0xFF1E1B72).withOpacity(0.04),
      blurRadius: 8,
      offset: const Offset(0, 2),
    ),
  ];

  static List<BoxShadow> colored(Color color, {double opacity = 0.3}) => [
    BoxShadow(
      color: color.withOpacity(opacity),
      blurRadius: 20,
      offset: const Offset(0, 6),
    ),
  ];
}

// ══════════════════════════════════════════
// 🎭 App Theme
// ══════════════════════════════════════════
class AppTheme {
  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: Brightness.light,
      primary: AppColors.primary,
      secondary: AppColors.purple,
      surface: AppColors.surface,
      background: AppColors.bg,
      error: AppColors.red,
    ),
    scaffoldBackgroundColor: AppColors.bg,
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.surface,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      iconTheme: const IconThemeData(color: AppColors.text),
      titleTextStyle: AppTextStyles.title.copyWith(fontSize: 18),
      surfaceTintColor: Colors.transparent,
    ),
    cardTheme: CardThemeData(
      color: AppColors.surface,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: AppRadius.medium),
      margin: EdgeInsets.zero,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
        textStyle: AppTextStyles.subtitle.copyWith(color: Colors.white),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.primary,
        side: const BorderSide(color: AppColors.border2),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: AppColors.primary,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.surface2,
      border: OutlineInputBorder(
        borderRadius: AppRadius.small,
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: AppRadius.small,
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: AppRadius.small,
        borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: AppRadius.small,
        borderSide: const BorderSide(color: AppColors.red),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: AppTextStyles.body.copyWith(color: AppColors.text3),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: AppColors.primary,
      foregroundColor: Colors.white,
      elevation: 4,
    ),
    dividerTheme: const DividerThemeData(
      color: AppColors.border,
      thickness: 1,
      space: 1,
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: AppColors.surface,
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.text3,
      elevation: 0,
      type: BottomNavigationBarType.fixed,
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: AppColors.text,
      contentTextStyle: AppTextStyles.body.copyWith(color: Colors.white),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.surface2,
      selectedColor: AppColors.primaryLight,
      labelStyle: AppTextStyles.label,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: AppRadius.xsmall),
      side: const BorderSide(color: AppColors.border),
    ),
  );

  static ThemeData get darkTheme => lightTheme; // placeholder
}

// ══════════════════════════════════════════
// 🛠️ Helper functions
// ══════════════════════════════════════════
String fmtAmount(double amount) {
  if (amount >= 1000000) {
    return '${(amount / 1000000).toStringAsFixed(1)}م';
  } else if (amount >= 1000) {
    return '${(amount / 1000).toStringAsFixed(1)}ك';
  }
  return amount.toStringAsFixed(0);
}

String fmtDate(DateTime? date) {
  if (date == null) return '—';
  final months = ['يناير','فبراير','مارس','أبريل','مايو','يونيو',
    'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}

String fmtDateShort(DateTime? date) {
  if (date == null) return '—';
  return '${date.day}/${date.month}/${date.year}';
}

String statusLabel(String status) {
  switch (status) {
    case 'pending': return 'قيد الانتظار';
    case 'inProgress': return 'جارٍ التنفيذ';
    case 'completed': return 'مكتمل';
    case 'cancelled': return 'ملغي';
    default: return status;
  }
}

Color statusColor(String status) {
  switch (status) {
    case 'pending': return AppColors.gold;
    case 'inProgress': return AppColors.blue;
    case 'completed': return AppColors.green;
    case 'cancelled': return AppColors.text3;
    default: return AppColors.text3;
  }
}

Color statusBg(String status) {
  switch (status) {
    case 'pending': return AppColors.goldLight;
    case 'inProgress': return AppColors.blueLight;
    case 'completed': return AppColors.greenLight;
    case 'cancelled': return AppColors.surface2;
    default: return AppColors.surface2;
  }
}

// Alias for Work model status values
String workStatusLabel(String status) {
  switch (status) {
    case 'pending': return 'قيد الانتظار';
    case 'inProgress': return 'جاري التنفيذ';
    case 'done': return 'منتهي';
    case 'delivered': return 'تم التسليم';
    case 'completed': return 'مكتمل';
    default: return status;
  }
}
