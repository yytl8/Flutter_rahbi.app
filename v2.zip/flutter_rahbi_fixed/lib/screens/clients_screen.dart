import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

// ══════════════════════════════════════════
// 👥 Clients List Screen
// ══════════════════════════════════════════
class ClientsScreen extends ConsumerStatefulWidget {
  const ClientsScreen({super.key});

  @override
  ConsumerState<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends ConsumerState<ClientsScreen> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final clientsAsync = ref.watch(clientsProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('العملاء'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddClient(context),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: AppSearchBar(
              hint: 'ابحث عن عميل...',
              controller: _search,
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: clientsAsync.when(
              data: (clients) {
                final filtered = _query.isEmpty
                    ? clients
                    : clients.where((c) => c.name.contains(_query)).toList();

                if (filtered.isEmpty) {
                  return EmptyState(
                    emoji: '👥',
                    message: _query.isEmpty ? 'لا يوجد عملاء بعد' : 'لا نتائج',
                    sub: _query.isEmpty ? 'اضغط + لإضافة عميل جديد' : null,
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) => _ClientCard(client: filtered[i]),
                );
              },
              loading: () => const LoadingList(),
              error: (e, _) => Center(child: Text('خطأ: $e')),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddClient(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => const _AddClientSheet(),
    );
  }
}

class _ClientCard extends ConsumerWidget {
  final Client client;
  const _ClientCard({required this.client});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: AppCard(
        onTap: () => context.go('/clients/${client.id}'),
        child: Row(
          children: [
            EntityAvatar(name: client.name, id: client.id),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(client.name, style: AppTextStyles.title),
                  if (client.phone != null)
                    Text(client.phone!, style: AppTextStyles.caption),
                  if (client.address != null)
                    Text(client.address!, style: AppTextStyles.caption),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: AppColors.text3),
          ],
        ),
      ),
    );
  }
}

class _AddClientSheet extends ConsumerStatefulWidget {
  const _AddClientSheet();

  @override
  ConsumerState<_AddClientSheet> createState() => _AddClientSheetState();
}

class _AddClientSheetState extends ConsumerState<_AddClientSheet> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _notes = TextEditingController();
  final _form = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);

    final shopId = ref.read(shopIdProvider)!;
    await FirebaseFirestore.instance
        .collection('shops')
        .doc(shopId)
        .collection('clients')
        .add({
      'shopId': shopId,
      'name': _name.text.trim(),
      'phone': _phone.text.trim().isEmpty ? null : _phone.text.trim(),
      'address': _address.text.trim().isEmpty ? null : _address.text.trim(),
      'notes': _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تمت إضافة العميل')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('إضافة عميل جديد', style: AppTextStyles.title),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const Divider(),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'اسم العميل *',
              hint: 'عبدالله محمد',
              controller: _name,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'رقم الهاتف',
              hint: '05xxxxxxxx',
              controller: _phone,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'العنوان',
              hint: 'الرياض، حي النزهة',
              controller: _address,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'ملاحظات',
              hint: 'أي ملاحظات إضافية...',
              controller: _notes,
              maxLines: 2,
            ),
            const SizedBox(height: AppSpacing.xl),
            PrimaryButton(
              label: 'حفظ العميل',
              icon: '💾',
              onTap: _save,
              isLoading: _loading,
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// 👤 Client Detail Screen
// ══════════════════════════════════════════
class ClientDetailScreen extends ConsumerStatefulWidget {
  final String id;
  const ClientDetailScreen({super.key, required this.id});

  @override
  ConsumerState<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends ConsumerState<ClientDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final clientsAsync = ref.watch(clientsProvider);
    final worksAsync = ref.watch(worksProvider);

    return clientsAsync.when(
      data: (clients) {
        final client = clients.firstWhere(
          (c) => c.id == widget.id,
          orElse: () => Client(id: '', shopId: '', name: 'غير موجود'),
        );

        final clientWorks = worksAsync.value
                ?.where((w) => w.clientId == widget.id)
                .toList() ??
            [];

        final totalAmount = clientWorks.fold(0.0, (s, w) => s + w.totalAmount);
        final totalPaid = clientWorks.fold(0.0, (s, w) => s + w.paidAmount);

        return Scaffold(
          backgroundColor: AppColors.bg,
          appBar: AppBar(
            title: Text(client.name),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => context.go('/clients'),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: () => _showAddWork(context, client),
                tooltip: 'إضافة عمل',
              ),
            ],
          ),
          body: Column(
            children: [
              // Client Info Card
              Padding(
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: AppCard(
                  child: Row(
                    children: [
                      EntityAvatar(name: client.name, id: client.id, size: 56),
                      const SizedBox(width: AppSpacing.md),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(client.name, style: AppTextStyles.title),
                            if (client.phone != null) ...[
                              const SizedBox(height: 2),
                              Text(client.phone!, style: AppTextStyles.caption),
                            ],
                            if (client.address != null) ...[
                              const SizedBox(height: 2),
                              Text(client.address!, style: AppTextStyles.caption),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Summary row
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                child: Row(
                  children: [
                    Expanded(
                      child: _MiniStat(
                        label: 'الإجمالي',
                        value: '${fmtAmount(totalAmount)} ر',
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: _MiniStat(
                        label: 'المدفوع',
                        value: '${fmtAmount(totalPaid)} ر',
                        color: AppColors.green,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: _MiniStat(
                        label: 'المتبقي',
                        value: '${fmtAmount(totalAmount - totalPaid)} ر',
                        color: AppColors.red,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.lg),

              // Tabs
              Container(
                color: AppColors.surface,
                child: TabBar(
                  controller: _tabs,
                  tabs: const [
                    Tab(text: 'الأعمال'),
                    Tab(text: 'المدفوعات'),
                    Tab(text: 'القياسات'),
                  ],
                ),
              ),

              Expanded(
                child: TabBarView(
                  controller: _tabs,
                  children: [
                    // Works tab
                    _WorksList(works: clientWorks, client: client, ref: ref, context: context),
                    // Payments tab
                    _PaymentsList(works: clientWorks),
                    // Measurements tab
                    _MeasurementsList(works: clientWorks),
                  ],
                ),
              ),
            ],
          ),
        );
      },
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('خطأ: $e'))),
    );
  }

  void _showAddWork(BuildContext context, Client client) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _AddWorkSheet(client: client),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: AppRadius.small,
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          Text(label, style: AppTextStyles.caption.copyWith(fontSize: 10)),
        ],
      ),
    );
  }
}

class _WorksList extends StatelessWidget {
  final List<Work> works;
  final Client client;
  final WidgetRef ref;
  final BuildContext context;

  const _WorksList({
    required this.works,
    required this.client,
    required this.ref,
    required this.context,
  });

  @override
  Widget build(BuildContext _) {
    if (works.isEmpty) {
      return const EmptyState(emoji: '🔨', message: 'لا توجد أعمال', sub: 'اضغط + لإضافة عمل');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: works.length,
      itemBuilder: (_, i) {
        final w = works[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(w.title, style: AppTextStyles.title)),
                    StatusBadge(
                      label: w.statusLabel,
                      color: w.status == 'done' ? AppColors.green : AppColors.blue,
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.sm),
                StatRow(
                  label: 'الإجمالي',
                  value: '${fmtAmount(w.totalAmount)} ر',
                  valueColor: AppColors.primary,
                ),
                StatRow(
                  label: 'المدفوع',
                  value: '${fmtAmount(w.paidAmount)} ر',
                  valueColor: AppColors.green,
                ),
                StatRow(
                  label: 'المتبقي',
                  value: '${fmtAmount(w.remaining)} ر',
                  valueColor: w.remaining > 0 ? AppColors.red : AppColors.green,
                ),
                const SizedBox(height: AppSpacing.sm),
                AppProgressBar(value: w.progressPct),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _PaymentsList extends StatelessWidget {
  final List<Work> works;
  const _PaymentsList({required this.works});

  @override
  Widget build(BuildContext context) {
    final payments = works.expand((w) => w.payments.map((p) => (work: w, payment: p))).toList();

    if (payments.isEmpty) {
      return const EmptyState(emoji: '💵', message: 'لا توجد مدفوعات بعد');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: payments.length,
      itemBuilder: (_, i) {
        final item = payments[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: AppCard(
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: AppColors.greenLight,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(child: Text('💵', style: TextStyle(fontSize: 18))),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.work.title, style: AppTextStyles.caption),
                      if (item.payment.note != null)
                        Text(item.payment.note!, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${fmtAmount(item.payment.amount)} ر',
                      style: AppTextStyles.subtitle.copyWith(color: AppColors.green),
                    ),
                    Text(item.payment.date, style: AppTextStyles.caption),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MeasurementsList extends StatelessWidget {
  final List<Work> works;
  const _MeasurementsList({required this.works});

  @override
  Widget build(BuildContext context) {
    final measurements = works
        .expand((w) => w.measurements.map((m) => (work: w, measurement: m)))
        .toList();

    if (measurements.isEmpty) {
      return const EmptyState(emoji: '📏', message: 'لا توجد قياسات بعد');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: measurements.length,
      itemBuilder: (_, i) {
        final item = measurements[i];
        final m = item.measurement;
        return Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(m.item, style: AppTextStyles.title),
                Text(item.work.title, style: AppTextStyles.caption),
                const SizedBox(height: AppSpacing.sm),
                Wrap(
                  spacing: 8,
                  children: [
                    if (m.width != null) _MeasChip('عرض: ${m.width}'),
                    if (m.height != null) _MeasChip('ارتفاع: ${m.height}'),
                    if (m.depth != null) _MeasChip('عمق: ${m.depth}'),
                  ],
                ),
                if (m.notes != null) ...[
                  const SizedBox(height: 4),
                  Text(m.notes!, style: AppTextStyles.caption),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MeasChip extends StatelessWidget {
  final String label;
  const _MeasChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.tealLight,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 11,
          color: AppColors.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _AddWorkSheet extends ConsumerStatefulWidget {
  final Client client;
  const _AddWorkSheet({required this.client});

  @override
  ConsumerState<_AddWorkSheet> createState() => _AddWorkSheetState();
}

class _AddWorkSheetState extends ConsumerState<_AddWorkSheet> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _amount = TextEditingController();
  final _form = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);

    final shopId = ref.read(shopIdProvider)!;
    await FirebaseFirestore.instance
        .collection('shops')
        .doc(shopId)
        .collection('works')
        .add({
      'shopId': shopId,
      'clientId': widget.client.id,
      'clientName': widget.client.name,
      'title': _title.text.trim(),
      'description': _desc.text.trim().isEmpty ? null : _desc.text.trim(),
      'totalAmount': double.tryParse(_amount.text) ?? 0,
      'paidAmount': 0,
      'status': 'pending',
      'payments': [],
      'measurements': [],
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تمت إضافة العمل')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('إضافة عمل جديد', style: AppTextStyles.title),
                const Spacer(),
                IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
              ],
            ),
            Text('للعميل: ${widget.client.name}', style: AppTextStyles.caption),
            const Divider(),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'عنوان العمل *',
              hint: 'غرفة نوم كاملة',
              controller: _title,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'الوصف',
              hint: 'تفاصيل إضافية...',
              controller: _desc,
              maxLines: 2,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'المبلغ الإجمالي (ر.س)',
              hint: '0',
              controller: _amount,
              keyboardType: TextInputType.number,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.xl),
            PrimaryButton(label: 'حفظ العمل', icon: '💾', onTap: _save, isLoading: _loading),
          ],
        ),
      ),
    );
  }
}
