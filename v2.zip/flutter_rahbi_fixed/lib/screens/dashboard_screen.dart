import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:fl_chart/fl_chart.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final shop = auth.shop;
    final user = auth.user;

    final clientsAsync = ref.watch(clientsProvider);
    final worksAsync = ref.watch(worksProvider);
    final workersAsync = ref.watch(workersProvider);
    final suppliersAsync = ref.watch(suppliersProvider);

    final works = worksAsync.value ?? [];
    final clients = clientsAsync.value ?? [];
    final workers = workersAsync.value ?? [];
    final suppliers = suppliersAsync.value ?? [];

    final totalRevenue = works.fold(0.0, (s, w) => s + w.totalAmount);
    final totalPaid = works.fold(0.0, (s, w) => s + w.paidAmount);
    final remaining = totalRevenue - totalPaid;
    final inProgress = works.where((w) => w.status == 'inProgress').length;
    final completed = works.where((w) => w.status == 'done' || w.status == 'delivered').length;
    final pending = works.where((w) => w.status == 'pending').length;
    final workerDebt = workers.fold(0.0, (s, w) => s + w.balance);
    final supplierDebt = suppliers.fold(0.0, (s, sp) => s + sp.remaining);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          // ── App Bar ──
          SliverAppBar(
            floating: true,
            pinned: true,
            backgroundColor: AppColors.surface,
            elevation: 0,
            scrolledUnderElevation: 0,
            toolbarHeight: 64,
            title: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primary, AppColors.primary2],
                    ),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Center(child: Text('🪵', style: TextStyle(fontSize: 19))),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(shop?.name ?? 'الرحبي للنجارة', style: AppTextStyles.title),
                    Text(
                      'مرحباً، ${user?.name ?? ''}',
                      style: AppTextStyles.caption.copyWith(fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.account_balance_wallet_outlined),
                tooltip: 'التدفق النقدي',
                onPressed: () => context.go('/cashflow'),
              ),
              IconButton(
                icon: const Icon(Icons.settings_outlined),
                tooltip: 'الإعدادات',
                onPressed: () => context.go('/settings'),
              ),
            ],
            bottom: const PreferredSize(
              preferredSize: Size.fromHeight(1),
              child: Divider(height: 1),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            sliver: SliverList(
              delegate: SliverChildListDelegate([

                // ── Net Profit Banner ──
                GradientCard(
                  colors: [AppColors.primary, AppColors.primary3],
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text('💎', style: TextStyle(fontSize: 26)),
                          const SizedBox(width: 10),
                          Text(
                            'صافي الربح التقديري',
                            style: AppTextStyles.body.copyWith(color: Colors.white70),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              '${works.length} عمل',
                              style: AppTextStyles.caption.copyWith(color: Colors.white70),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '${fmtAmount(totalPaid - workerDebt - supplierDebt)} ريال',
                        style: const TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: -1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'المحصّل ${fmtAmount(totalPaid)} — ديون عمال ${fmtAmount(workerDebt)} — ديون موردين ${fmtAmount(supplierDebt)}',
                        style: AppTextStyles.caption.copyWith(color: Colors.white60, fontSize: 11),
                      ),
                    ],
                  ),
                ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.1),

                const SizedBox(height: AppSpacing.lg),

                // ── Stats Grid ──
                Row(
                  children: [
                    Expanded(
                      child: SummaryCard(
                        label: 'إجمالي الأعمال',
                        value: '${fmtAmount(totalRevenue)} ر',
                        icon: '💰',
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: SummaryCard(
                        label: 'تم تحصيله',
                        value: '${fmtAmount(totalPaid)} ر',
                        icon: '✅',
                        color: AppColors.green,
                      ),
                    ),
                  ],
                ).animate(delay: 100.ms).fadeIn().slideY(begin: 0.1),

                const SizedBox(height: AppSpacing.md),

                Row(
                  children: [
                    Expanded(
                      child: SummaryCard(
                        label: 'المتبقي',
                        value: '${fmtAmount(remaining)} ر',
                        icon: '⏳',
                        color: AppColors.gold,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: SummaryCard(
                        label: 'قيد التنفيذ',
                        value: '$inProgress عمل',
                        icon: '🔨',
                        color: AppColors.blue,
                      ),
                    ),
                  ],
                ).animate(delay: 150.ms).fadeIn().slideY(begin: 0.1),

                const SizedBox(height: AppSpacing.lg),

                // ── Works Status Chart ──
                if (works.isNotEmpty) ...[
                  const SectionHeader(title: 'حالة الأعمال'),
                  const SizedBox(height: AppSpacing.md),
                  AppCard(
                    child: Row(
                      children: [
                        SizedBox(
                          width: 120,
                          height: 120,
                          child: PieChart(
                            PieChartData(
                              sections: [
                                if (inProgress > 0)
                                  PieChartSectionData(
                                    value: inProgress.toDouble(),
                                    color: AppColors.blue,
                                    title: '$inProgress',
                                    titleStyle: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                    radius: 40,
                                  ),
                                if (completed > 0)
                                  PieChartSectionData(
                                    value: completed.toDouble(),
                                    color: AppColors.green,
                                    title: '$completed',
                                    titleStyle: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                    radius: 40,
                                  ),
                                if (pending > 0)
                                  PieChartSectionData(
                                    value: pending.toDouble(),
                                    color: AppColors.gold,
                                    title: '$pending',
                                    titleStyle: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                    radius: 40,
                                  ),
                              ],
                              centerSpaceRadius: 30,
                              sectionsSpace: 2,
                            ),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.lg),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _LegendItem(label: 'جاري التنفيذ', count: inProgress, color: AppColors.blue),
                              const SizedBox(height: 10),
                              _LegendItem(label: 'مكتملة', count: completed, color: AppColors.green),
                              const SizedBox(height: 10),
                              _LegendItem(label: 'قيد الانتظار', count: pending, color: AppColors.gold),
                              const SizedBox(height: 10),
                              _LegendItem(label: 'إجمالي', count: works.length, color: AppColors.text2),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ).animate(delay: 200.ms).fadeIn(),
                  const SizedBox(height: AppSpacing.lg),
                ],

                // ── Progress Bar Section ──
                const SectionHeader(title: 'نسبة التحصيل'),
                const SizedBox(height: AppSpacing.md),
                AppCard(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('${fmtAmount(totalPaid)} ر محصّل', style: AppTextStyles.subtitle),
                          Text(
                            totalRevenue > 0
                                ? '${((totalPaid / totalRevenue) * 100).toStringAsFixed(0)}%'
                                : '0%',
                            style: AppTextStyles.title.copyWith(color: AppColors.green),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.sm),
                      AppProgressBar(
                        value: totalRevenue > 0 ? totalPaid / totalRevenue : 0,
                        color: AppColors.green,
                        height: 8,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'متبقي ${fmtAmount(remaining)} ريال من ${fmtAmount(totalRevenue)} ريال',
                        style: AppTextStyles.caption,
                      ),
                    ],
                  ),
                ).animate(delay: 250.ms).fadeIn(),

                const SizedBox(height: AppSpacing.lg),

                // ── Quick Stats Row ──
                const SectionHeader(title: 'ملخص سريع'),
                const SizedBox(height: AppSpacing.md),
                Row(
                  children: [
                    Expanded(
                      child: _QuickStat(
                        label: 'العملاء',
                        value: '${clients.length}',
                        icon: '👥',
                        color: AppColors.purple,
                        onTap: () => context.go('/clients'),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: _QuickStat(
                        label: 'العمال',
                        value: '${workers.length}',
                        icon: '👷',
                        color: AppColors.orange,
                        onTap: () => context.go('/workers'),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: _QuickStat(
                        label: 'الموردون',
                        value: '${suppliers.length}',
                        icon: '🏭',
                        color: AppColors.red,
                        onTap: () => context.go('/suppliers'),
                      ),
                    ),
                  ],
                ).animate(delay: 300.ms).fadeIn(),

                const SizedBox(height: AppSpacing.lg),

                // ── Recent Works ──
                if (works.isNotEmpty) ...[
                  SectionHeader(
                    title: 'أحدث الأعمال',
                    action: 'عرض الكل',
                    onAction: () => context.go('/clients'),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  ...works.take(5).map((w) => Padding(
                    padding: const EdgeInsets.only(bottom: AppSpacing.md),
                    child: _WorkCard(work: w),
                  )),
                ],

                const SizedBox(height: 100),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  final String label;
  final int count;
  final Color color;

  const _LegendItem({required this.label, required this.count, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(label, style: AppTextStyles.caption)),
        Text('$count', style: AppTextStyles.subtitle.copyWith(color: color)),
      ],
    );
  }
}

class _QuickStat extends StatelessWidget {
  final String label;
  final String value;
  final String icon;
  final Color color;
  final VoidCallback onTap;

  const _QuickStat({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Column(
        children: [
          Text(icon, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color)),
          Text(label, style: AppTextStyles.caption, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _WorkCard extends StatelessWidget {
  final Work work;
  const _WorkCard({required this.work});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Row(
        children: [
          EntityAvatar(name: work.title, id: work.id, size: 46, emoji: '🔨'),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(work.title, style: AppTextStyles.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
                Text(work.clientName, style: AppTextStyles.caption),
                const SizedBox(height: 4),
                AppProgressBar(
                  value: work.totalAmount > 0 ? work.paidAmount / work.totalAmount : 0,
                  height: 4,
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              StatusBadge(
                label: statusLabel(work.status),
                color: statusColor(work.status),
              ),
              const SizedBox(height: 4),
              Text(
                '${fmtAmount(work.totalAmount)} ر',
                style: AppTextStyles.subtitle.copyWith(color: AppColors.primary),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
