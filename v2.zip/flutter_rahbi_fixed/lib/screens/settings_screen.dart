import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../widgets/common_widgets.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final user = auth.user;
    final shop = auth.shop;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('الإعدادات ⚙️')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          // Profile card
          AppCard(
            child: Row(
              children: [
                EntityAvatar(name: user?.name ?? '', id: user?.id ?? '', size: 56),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(user?.name ?? '', style: AppTextStyles.title),
                      Text(user?.email ?? '', style: AppTextStyles.caption),
                      const SizedBox(height: 4),
                      StatusBadge(
                        label: user?.role == 'admin' ? '👑 مدير' : '👷 عامل',
                        color: AppColors.primary,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: AppSpacing.lg),

          // Shop info
          if (shop != null) ...[
            _SettingsSection(title: 'معلومات المحل', items: [
              _SettingsTile(icon: '🏪', label: shop.name, sub: 'اسم المحل'),
              if (shop.phone != null)
                _SettingsTile(icon: '📞', label: shop.phone!, sub: 'الهاتف'),
              if (shop.address != null)
                _SettingsTile(icon: '📍', label: shop.address!, sub: 'العنوان'),
            ]),
            const SizedBox(height: AppSpacing.lg),
          ],

          // App info
          _SettingsSection(title: 'عن التطبيق', items: [
            const _SettingsTile(icon: '📱', label: 'الرحبي للنجارة', sub: 'الإصدار 2.0.0'),
            const _SettingsTile(icon: '🔥', label: 'Firebase Firestore', sub: 'قاعدة البيانات'),
            const _SettingsTile(icon: '🤖', label: 'Claude Sonnet', sub: 'محرك AI'),
          ]),

          const SizedBox(height: AppSpacing.xl),

          // Logout button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => _confirmLogout(context, ref),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.red,
                side: const BorderSide(color: AppColors.red),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              icon: const Icon(Icons.logout),
              label: const Text(
                'تسجيل الخروج',
                style: TextStyle(fontFamily: 'Cairo', fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),

          const SizedBox(height: 80),
        ],
      ),
    );
  }

  void _confirmLogout(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل أنت متأكد من تسجيل الخروج؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ref.read(authProvider.notifier).logout();
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.red),
            child: const Text('خروج'),
          ),
        ],
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> items;
  const _SettingsSection({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 4, bottom: 8),
          child: Text(title, style: AppTextStyles.label),
        ),
        AppCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: items.asMap().entries.map((e) {
              final isLast = e.key == items.length - 1;
              return Column(
                children: [
                  e.value,
                  if (!isLast) const Divider(height: 1),
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final String icon;
  final String label;
  final String sub;
  final VoidCallback? onTap;

  const _SettingsTile({required this.icon, required this.label, required this.sub, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Text(icon, style: const TextStyle(fontSize: 20)),
      title: Text(label, style: AppTextStyles.body),
      subtitle: Text(sub, style: AppTextStyles.caption),
      trailing: onTap != null ? const Icon(Icons.chevron_right, color: AppColors.text3) : null,
      onTap: onTap,
    );
  }
}
