import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

// ══════════════════════════════════════════
// 🏪 Shop Select Screen
// ══════════════════════════════════════════
class ShopSelectScreen extends ConsumerWidget {
  const ShopSelectScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).user!;
    final shopsAsync = ref.watch(allShopsProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(AppSpacing.xxl),
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.primary2],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: AppShadows.colored(AppColors.primary),
                    ),
                    child: const Center(child: Text('🏪', style: TextStyle(fontSize: 32))),
                  ),
                  const SizedBox(height: 16),
                  Text('اختر المحل', style: AppTextStyles.headline2),
                  const SizedBox(height: 6),
                  Text('مرحباً ${user.name}', style: AppTextStyles.body),
                ],
              ),
            ),
            Expanded(
              child: shopsAsync.when(
                data: (shops) => shops.isEmpty
                    ? const EmptyState(emoji: '🏪', message: 'لا توجد محلات بعد')
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
                        itemCount: shops.length,
                        itemBuilder: (_, i) => _ShopCard(shop: shops[i]),
                      ),
                loading: () => const LoadingList(count: 3),
                error: (e, _) => Center(child: Text('خطأ: $e')),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.xl),
              child: TextButton.icon(
                onPressed: () => ref.read(authProvider.notifier).logout(),
                icon: const Icon(Icons.logout, size: 16),
                label: const Text('تسجيل الخروج'),
                style: TextButton.styleFrom(foregroundColor: AppColors.red),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShopCard extends ConsumerWidget {
  final Shop shop;
  const _ShopCard({required this.shop});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final color = AppColors.entityColor(shop.id);
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: AppCard(
        onTap: () => ref.read(authProvider.notifier).selectShop(shop),
        child: Row(
          children: [
            EntityAvatar(name: shop.name, id: shop.id, size: 52, emoji: '🏪'),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(shop.name, style: AppTextStyles.title),
                  if (shop.address != null)
                    Text(shop.address!, style: AppTextStyles.caption),
                  if (!shop.isActive)
                    const StatusBadge(label: 'غير نشط', color: AppColors.text3),
                ],
              ),
            ),
            Icon(Icons.chevron_left_rounded, color: color),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// 🏠 Main Shell — Admin Bottom Nav
// ══════════════════════════════════════════
class MainShell extends ConsumerStatefulWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _selectedIndex = 0;

  static const _routes = [
    '/home',
    '/clients',
    '/workers',
    '/suppliers',
    '/ai-analyzer',
  ];

  static const _navItems = [
    NavigationDestination(
      icon: Icon(Icons.home_outlined),
      selectedIcon: Icon(Icons.home_rounded),
      label: 'الرئيسية',
    ),
    NavigationDestination(
      icon: Icon(Icons.people_outlined),
      selectedIcon: Icon(Icons.people_rounded),
      label: 'العملاء',
    ),
    NavigationDestination(
      icon: Icon(Icons.engineering_outlined),
      selectedIcon: Icon(Icons.engineering_rounded),
      label: 'العمال',
    ),
    NavigationDestination(
      icon: Icon(Icons.warehouse_outlined),
      selectedIcon: Icon(Icons.warehouse_rounded),
      label: 'الموردون',
    ),
    NavigationDestination(
      icon: Icon(Icons.auto_awesome_outlined),
      selectedIcon: Icon(Icons.auto_awesome_rounded),
      label: 'محلل AI',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widget.child,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: NavigationBar(
          selectedIndex: _selectedIndex,
          destinations: _navItems,
          onDestinationSelected: (i) {
            setState(() => _selectedIndex = i);
            context.go(_routes[i]);
          },
          backgroundColor: AppColors.surface,
          surfaceTintColor: Colors.transparent,
          indicatorColor: AppColors.primaryLight,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          height: 68,
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// 👷 Worker Portal Shell
// ══════════════════════════════════════════
class WorkerPortalShell extends StatelessWidget {
  final Widget child;
  const WorkerPortalShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) => Scaffold(body: child);
}
