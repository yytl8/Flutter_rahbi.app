import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

class CashflowScreen extends ConsumerWidget {
  const CashflowScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final works = ref.watch(worksProvider).value ?? [];
    final workers = ref.watch(workersProvider).value ?? [];
    final suppliers = ref.watch(suppliersProvider).value ?? [];

    final totalRevenue = works.fold(0.0, (s, w) => s + w.totalAmount);
    final totalCollected = works.fold(0.0, (s, w) => s + w.paidAmount);
    final totalRemaining = totalRevenue - totalCollected;
    final totalWorkerDebt = workers.fold(0.0, (s, w) => s + w.balance);
    final totalSupplierDebt = suppliers.fold(0.0, (s, sp) => sp.remaining + s);
    final netProfit = totalCollected - totalWorkerDebt - totalSupplierDebt;
    final collectionPct = totalRevenue > 0 ? totalCollected / totalRevenue : 0.0;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('التدفق النقدي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.pie_chart_outline_rounded),
            tooltip: 'تقرير',
            onPressed: () {},
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [

          // ── Net Profit Banner ──
          GradientCard(
            colors: [AppColors.primary, AppColors.primary3],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text('💎', style: TextStyle(fontSize: 36)),
                const SizedBox(height: 8),
                const Text(
                  'صافي الربح التقديري',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 6),
                Text(
                  '${fmtAmount(netProfit)} ريال',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -1,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _NetItem(label: 'محصّل', value: fmtAmount(totalCollected), icon: '📥'),
                    _Dot(),
                    _NetItem(label: 'عمال', value: fmtAmount(totalWorkerDebt), icon: '👷'),
                    _Dot(),
                    _NetItem(label: 'موردون', value: fmtAmount(totalSupplierDebt), icon: '🏭'),
                  ],
                ),
              ],
            ),
          ).animate().fadeIn(duration: 400.ms),

          const SizedBox(height: AppSpacing.lg),

          // ── Collection Bar Chart ──
          const SectionHeader(title: 'نسبة التحصيل'),
          const SizedBox(height: AppSpacing.md),
          AppCard(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${fmtAmount(totalCollected)} ر', style: AppTextStyles.amount),
                        Text('تم التحصيل', style: AppTextStyles.caption),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${(collectionPct * 100).toStringAsFixed(0)}%',
                          style: AppTextStyles.headline2.copyWith(color: AppColors.green),
                        ),
                        Text('من ${fmtAmount(totalRevenue)} ر', style: AppTextStyles.caption),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                AppProgressBar(value: collectionPct, color: AppColors.green, height: 10),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _ChipStat(label: 'المتبقي', value: '${fmtAmount(totalRemaining)} ر', color: AppColors.gold),
                    _ChipStat(label: 'الإجمالي', value: '${fmtAmount(totalRevenue)} ر', color: AppColors.primary),
                  ],
                ),
              ],
            ),
          ).animate(delay: 100.ms).fadeIn(),

          const SizedBox(height: AppSpacing.lg),

          // ── Income vs Expenses Grid ──
          const SectionHeader(title: 'الإيرادات والمصروفات'),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              Expanded(
                child: SummaryCard(
                  label: 'إجمالي العقود',
                  value: '${fmtAmount(totalRevenue)} ر',
                  icon: '📋',
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: SummaryCard(
                  label: 'تم تحصيله',
                  value: '${fmtAmount(totalCollected)} ر',
                  icon: '✅',
                  color: AppColors.green,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              Expanded(
                child: SummaryCard(
                  label: 'مستحقات العمال',
                  value: '${fmtAmount(totalWorkerDebt)} ر',
                  icon: '👷',
                  color: AppColors.orange,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: SummaryCard(
                  label: 'ديون الموردين',
                  value: '${fmtAmount(totalSupplierDebt)} ر',
                  icon: '🏭',
                  color: AppColors.red,
                ),
              ),
            ],
          ).animate(delay: 150.ms).fadeIn(),

          const SizedBox(height: AppSpacing.lg),

          // ── Works Breakdown ──
          SectionHeader(
            title: 'تفصيل الأعمال (${works.length})',
            color: AppColors.blue,
          ),
          const SizedBox(height: AppSpacing.md),

          if (works.isEmpty)
            const EmptyState(emoji: '💰', message: 'لا توجد أعمال مسجلة بعد')
          else
            ...works.asMap().entries.map((e) => Padding(
              padding: const EdgeInsets.only(bottom: AppSpacing.md),
              child: _WorkRow(work: e.value)
                  .animate(delay: Duration(milliseconds: 50 * e.key))
                  .fadeIn()
                  .slideX(begin: 0.1),
            )),

          const SizedBox(height: 100),
        ],
      ),
    );
  }
}

class _NetItem extends StatelessWidget {
  final String label;
  final String value;
  final String icon;
  const _NetItem({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Text(icon, style: const TextStyle(fontSize: 14)),
      Text(value, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
    ],
  );
}

class _Dot extends StatelessWidget {
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.symmetric(horizontal: 12),
    child: Text('·', style: TextStyle(color: Colors.white38, fontSize: 20)),
  );
}

class _ChipStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _ChipStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(AppRadius.sm),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: AppTextStyles.caption),
        const SizedBox(width: 6),
        Text(value, style: TextStyle(fontWeight: FontWeight.w700, color: color, fontSize: 13)),
      ],
    ),
  );
}

class _WorkRow extends StatelessWidget {
  final Work work;
  const _WorkRow({required this.work});

  @override
  Widget build(BuildContext context) {
    final pct = work.totalAmount > 0 ? work.paidAmount / work.totalAmount : 0.0;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(work.title, style: AppTextStyles.subtitle),
                    Text(work.clientName, style: AppTextStyles.caption),
                  ],
                ),
              ),
              StatusBadge(
                label: work.statusLabel,
                color: work.status == 'done' || work.status == 'delivered' ? AppColors.green : work.status == 'inProgress' ? AppColors.blue : AppColors.gold,
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    StatRow(
                      label: 'الإجمالي',
                      value: '${fmtAmount(work.totalAmount)} ر',
                      valueColor: AppColors.primary,
                    ),
                    StatRow(
                      label: 'المحصّل',
                      value: '${fmtAmount(work.paidAmount)} ر',
                      valueColor: AppColors.green,
                    ),
                    StatRow(
                      label: 'المتبقي',
                      value: '${fmtAmount(work.remaining)} ر',
                      valueColor: work.remaining > 0 ? AppColors.red : AppColors.green,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.lg),
              SizedBox(
                width: 60,
                height: 60,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CircularProgressIndicator(
                      value: pct.clamp(0.0, 1.0),
                      backgroundColor: AppColors.border,
                      valueColor: AlwaysStoppedAnimation(work.status == 'done' || work.status == 'delivered' ? AppColors.green : work.status == 'inProgress' ? AppColors.blue : AppColors.gold),
                      strokeWidth: 5,
                    ),
                    Text(
                      '${(pct * 100).toStringAsFixed(0)}%',
                      style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          AppProgressBar(
            value: pct,
            color: work.status == 'done' || work.status == 'delivered' ? AppColors.green : work.status == 'inProgress' ? AppColors.blue : AppColors.gold,
            height: 5,
          ),
        ],
      ),
    );
  }
}
