import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

// ══════════════════════════════════════════
// 👷 Workers List Screen
// ══════════════════════════════════════════
class WorkersScreen extends ConsumerStatefulWidget {
  const WorkersScreen({super.key});

  @override
  ConsumerState<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends ConsumerState<WorkersScreen> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final workersAsync = ref.watch(workersProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('العمال'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddWorker(context),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: AppSearchBar(
              hint: 'ابحث عن عامل...',
              controller: _search,
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          // Summary bar
          workersAsync.when(
            data: (workers) {
              final totalBalance = workers.fold(0.0, (s, w) => s + w.balance);
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                child: Row(
                  children: [
                    Expanded(
                      child: _SummaryPill(
                        label: 'عدد العمال',
                        value: '${workers.length}',
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: _SummaryPill(
                        label: 'المستحقات',
                        value: '${fmtAmount(totalBalance)} ر',
                        color: AppColors.gold,
                      ),
                    ),
                  ],
                ),
              );
            },
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
          ),
          const SizedBox(height: AppSpacing.md),
          Expanded(
            child: workersAsync.when(
              data: (workers) {
                final filtered = _query.isEmpty
                    ? workers
                    : workers.where((w) => w.name.contains(_query)).toList();

                if (filtered.isEmpty) {
                  return EmptyState(
                    emoji: '👷',
                    message: _query.isEmpty ? 'لا يوجد عمال بعد' : 'لا نتائج',
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) => _WorkerCard(worker: filtered[i]),
                );
              },
              loading: () => const LoadingList(),
              error: (e, _) => Center(child: Text('خطأ: $e')),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddWorker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => const _AddWorkerSheet(),
    );
  }
}

class _SummaryPill extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _SummaryPill({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: AppRadius.small,
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Expanded(child: Text(label, style: AppTextStyles.caption)),
          Text(
            value,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkerCard extends ConsumerWidget {
  final Worker worker;
  const _WorkerCard({required this.worker});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: AppCard(
        onTap: () => context.go('/workers/${worker.id}'),
        child: Column(
          children: [
            Row(
              children: [
                EntityAvatar(name: worker.name, id: worker.id, emoji: '👷'),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(worker.name, style: AppTextStyles.title),
                      if (worker.specialty != null)
                        Text(worker.specialty!, style: AppTextStyles.caption),
                      if (worker.phone != null)
                        Text(worker.phone!, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${fmtAmount(worker.balance)} ر',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: worker.balance > 0 ? AppColors.gold : AppColors.green,
                      ),
                    ),
                    Text('الرصيد', style: AppTextStyles.caption),
                  ],
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: [
                Expanded(
                  child: StatRow(
                    label: 'المكتسب',
                    value: '${fmtAmount(worker.totalEarned)} ر',
                    valueColor: AppColors.primary,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: StatRow(
                    label: 'المسحوب',
                    value: '${fmtAmount(worker.totalWithdrawn)} ر',
                    valueColor: AppColors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AddWorkerSheet extends ConsumerStatefulWidget {
  const _AddWorkerSheet();

  @override
  ConsumerState<_AddWorkerSheet> createState() => _AddWorkerSheetState();
}

class _AddWorkerSheetState extends ConsumerState<_AddWorkerSheet> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _specialty = TextEditingController();
  final _daily = TextEditingController();
  final _form = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _specialty.dispose();
    _daily.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);

    final shopId = ref.read(shopIdProvider)!;
    await FirebaseFirestore.instance
        .collection('shops')
        .doc(shopId)
        .collection('workers')
        .add({
      'shopId': shopId,
      'name': _name.text.trim(),
      'phone': _phone.text.trim().isEmpty ? null : _phone.text.trim(),
      'specialty': _specialty.text.trim().isEmpty ? null : _specialty.text.trim(),
      'dailyRate': double.tryParse(_daily.text) ?? 0,
      'withdrawals': [],
      'jobs': [],
      'permissions': {},
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تمت إضافة العامل')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('إضافة عامل جديد', style: AppTextStyles.title),
                const Spacer(),
                IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
              ],
            ),
            const Divider(),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'اسم العامل *',
              hint: 'محمد السالم',
              controller: _name,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'رقم الهاتف',
              hint: '05xxxxxxxx',
              controller: _phone,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'التخصص',
              hint: 'نجار، دهان، ...',
              controller: _specialty,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'الأجر اليومي (ر.س)',
              hint: '250',
              controller: _daily,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: AppSpacing.xl),
            PrimaryButton(label: 'حفظ العامل', icon: '💾', onTap: _save, isLoading: _loading),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// Placeholder for worker detail
// ══════════════════════════════════════════
class WorkerDetailScreen extends ConsumerWidget {
  final String id;
  const WorkerDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final workersAsync = ref.watch(workersProvider);

    return workersAsync.when(
      data: (workers) {
        final worker = workers.firstWhere(
          (w) => w.id == id,
          orElse: () => Worker(id: '', shopId: '', name: 'غير موجود'),
        );

        return Scaffold(
          backgroundColor: AppColors.bg,
          appBar: AppBar(
            title: Text(worker.name),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => context.go('/workers'),
            ),
          ),
          body: ListView(
            padding: const EdgeInsets.all(AppSpacing.lg),
            children: [
              AppCard(
                child: Column(
                  children: [
                    EntityAvatar(name: worker.name, id: worker.id, size: 60, emoji: '👷'),
                    const SizedBox(height: 12),
                    Text(worker.name, style: AppTextStyles.title),
                    if (worker.specialty != null) Text(worker.specialty!, style: AppTextStyles.caption),
                    const SizedBox(height: AppSpacing.md),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _StatCol('المكتسب', '${fmtAmount(worker.totalEarned)} ر', AppColors.primary),
                        _StatCol('المسحوب', '${fmtAmount(worker.totalWithdrawn)} ر', AppColors.red),
                        _StatCol('الرصيد', '${fmtAmount(worker.balance)} ر', AppColors.gold),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: AppSpacing.lg),
              Text('الأعمال المنجزة', style: AppTextStyles.title),
              const SizedBox(height: AppSpacing.md),
              if (worker.jobs.isEmpty)
                const EmptyState(emoji: '🔨', message: 'لا توجد أعمال مسجلة')
              else
                ...worker.jobs.map((j) => Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.md),
                  child: AppCard(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(j.title, style: AppTextStyles.title),
                              Text(j.date, style: AppTextStyles.caption),
                            ],
                          ),
                        ),
                        Text(
                          '${fmtAmount(j.amount)} ر',
                          style: AppTextStyles.subtitle.copyWith(color: AppColors.primary),
                        ),
                      ],
                    ),
                  ),
                )),

              const SizedBox(height: AppSpacing.lg),
              Text('السحوبات', style: AppTextStyles.title),
              const SizedBox(height: AppSpacing.md),
              if (worker.withdrawals.isEmpty)
                const EmptyState(emoji: '💵', message: 'لا توجد سحوبات')
              else
                ...worker.withdrawals.map((w) => Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.md),
                  child: AppCard(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(w.note ?? 'سحب', style: AppTextStyles.title),
                              Text(w.date, style: AppTextStyles.caption),
                            ],
                          ),
                        ),
                        Text(
                          '${fmtAmount(w.amount)} ر',
                          style: AppTextStyles.subtitle.copyWith(color: AppColors.red),
                        ),
                      ],
                    ),
                  ),
                )),
            ],
          ),
        );
      },
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('خطأ: $e'))),
    );
  }
}

class _StatCol extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatCol(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: TextStyle(fontFamily: 'Cairo', fontSize: 14, fontWeight: FontWeight.w700, color: color)),
        Text(label, style: AppTextStyles.caption),
      ],
    );
  }
}
