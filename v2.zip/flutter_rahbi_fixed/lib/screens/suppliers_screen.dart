import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

class SuppliersScreen extends ConsumerStatefulWidget {
  const SuppliersScreen({super.key});

  @override
  ConsumerState<SuppliersScreen> createState() => _SuppliersScreenState();
}

class _SuppliersScreenState extends ConsumerState<SuppliersScreen> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final suppliersAsync = ref.watch(suppliersProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('الموردون'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddSupplier(context),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: AppSearchBar(
              hint: 'ابحث عن مورد...',
              controller: _search,
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: suppliersAsync.when(
              data: (suppliers) {
                final filtered = _query.isEmpty
                    ? suppliers
                    : suppliers.where((s) => s.name.contains(_query)).toList();

                if (filtered.isEmpty) {
                  return EmptyState(
                    emoji: '🏭',
                    message: _query.isEmpty ? 'لا يوجد موردون بعد' : 'لا نتائج',
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) => _SupplierCard(supplier: filtered[i]),
                );
              },
              loading: () => const LoadingList(),
              error: (e, _) => Center(child: Text('خطأ: $e')),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddSupplier(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => const _AddSupplierSheet(),
    );
  }
}

class _SupplierCard extends ConsumerWidget {
  final Supplier supplier;
  const _SupplierCard({required this.supplier});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final remaining = supplier.remaining;
    final pct = supplier.totalPurchases > 0
        ? (supplier.totalPaid / supplier.totalPurchases).clamp(0.0, 1.0)
        : 0.0;

    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: AppCard(
        onTap: () => context.go('/suppliers/${supplier.id}'),
        child: Column(
          children: [
            Row(
              children: [
                EntityAvatar(name: supplier.name, id: supplier.id, emoji: '🏭'),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(supplier.name, style: AppTextStyles.title),
                      Text(
                        '${supplier.goodsType ?? '—'}${supplier.phone != null ? ' • ${supplier.phone}' : ''}',
                        style: AppTextStyles.caption,
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: AppColors.text3),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            StatRow(
              label: 'المشتريات',
              value: '${fmtAmount(supplier.totalPurchases)} ر',
              valueColor: AppColors.gold,
            ),
            StatRow(
              label: 'المدفوع',
              value: '${fmtAmount(supplier.totalPaid)} ر',
              valueColor: AppColors.green,
            ),
            StatRow(
              label: 'المتبقي',
              value: '${fmtAmount(remaining)} ر',
              valueColor: remaining > 0 ? AppColors.red : AppColors.green,
            ),
            const SizedBox(height: AppSpacing.sm),
            AppProgressBar(value: pct.toDouble()),
          ],
        ),
      ),
    );
  }
}

class _AddSupplierSheet extends ConsumerStatefulWidget {
  const _AddSupplierSheet();

  @override
  ConsumerState<_AddSupplierSheet> createState() => _AddSupplierSheetState();
}

class _AddSupplierSheetState extends ConsumerState<_AddSupplierSheet> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _goods = TextEditingController();
  final _address = TextEditingController();
  final _form = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _goods.dispose();
    _address.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);

    final shopId = ref.read(shopIdProvider)!;
    await FirebaseFirestore.instance
        .collection('shops')
        .doc(shopId)
        .collection('suppliers')
        .add({
      'shopId': shopId,
      'name': _name.text.trim(),
      'phone': _phone.text.trim().isEmpty ? null : _phone.text.trim(),
      'goodsType': _goods.text.trim().isEmpty ? null : _goods.text.trim(),
      'address': _address.text.trim().isEmpty ? null : _address.text.trim(),
      'purchases': [],
      'payments': [],
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تمت إضافة المورد')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('إضافة مورد جديد', style: AppTextStyles.title),
                const Spacer(),
                IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
              ],
            ),
            const Divider(),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'اسم المورد *',
              hint: 'شركة الأخشاب الوطنية',
              controller: _name,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'رقم الهاتف',
              hint: '05xxxxxxxx',
              controller: _phone,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'نوع البضاعة',
              hint: 'أخشاب، حديد، دهانات...',
              controller: _goods,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'العنوان',
              hint: 'المنطقة الصناعية...',
              controller: _address,
            ),
            const SizedBox(height: AppSpacing.xl),
            PrimaryButton(label: 'حفظ المورد', icon: '💾', onTap: _save, isLoading: _loading),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// Supplier Detail
// ══════════════════════════════════════════
class SupplierDetailScreen extends ConsumerWidget {
  final String id;
  const SupplierDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final suppliersAsync = ref.watch(suppliersProvider);

    return suppliersAsync.when(
      data: (suppliers) {
        final supplier = suppliers.firstWhere(
          (s) => s.id == id,
          orElse: () => Supplier(id: '', shopId: '', name: 'غير موجود'),
        );

        return Scaffold(
          backgroundColor: AppColors.bg,
          appBar: AppBar(
            title: Text(supplier.name),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => context.go('/suppliers'),
            ),
          ),
          body: ListView(
            padding: const EdgeInsets.all(AppSpacing.lg),
            children: [
              AppCard(
                child: Column(
                  children: [
                    EntityAvatar(name: supplier.name, id: supplier.id, size: 60, emoji: '🏭'),
                    const SizedBox(height: 12),
                    Text(supplier.name, style: AppTextStyles.title),
                    if (supplier.goodsType != null) Text(supplier.goodsType!, style: AppTextStyles.caption),
                    const SizedBox(height: AppSpacing.md),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _Col('المشتريات', '${fmtAmount(supplier.totalPurchases)} ر', AppColors.gold),
                        _Col('المدفوع', '${fmtAmount(supplier.totalPaid)} ر', AppColors.green),
                        _Col('المتبقي', '${fmtAmount(supplier.remaining)} ر', AppColors.red),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: AppSpacing.lg),
              Text('سجل المشتريات', style: AppTextStyles.title),
              const SizedBox(height: AppSpacing.md),
              if (supplier.purchases.isEmpty)
                const EmptyState(emoji: '📦', message: 'لا توجد مشتريات مسجلة')
              else
                ...supplier.purchases.map((p) => Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.md),
                  child: AppCard(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (p.item != null) Text(p.item!, style: AppTextStyles.title),
                              if (p.note != null) Text(p.note!, style: AppTextStyles.caption),
                              Text(p.date, style: AppTextStyles.caption),
                            ],
                          ),
                        ),
                        Text('${fmtAmount(p.amount)} ر',
                            style: AppTextStyles.subtitle.copyWith(color: AppColors.gold)),
                      ],
                    ),
                  ),
                )),
            ],
          ),
        );
      },
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('خطأ: $e'))),
    );
  }
}

class _Col extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _Col(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: TextStyle(fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w700, color: color)),
        Text(label, style: AppTextStyles.caption),
      ],
    );
  }
}
