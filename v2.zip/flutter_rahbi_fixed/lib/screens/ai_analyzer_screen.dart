import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../core/theme.dart';
import '../widgets/common_widgets.dart';

// ══════════════════════════════════════════
// 🤖 AI Analyzer Screen — محلل AI
// ══════════════════════════════════════════

const _productTypes = [
  ('🚪', 'باب'),
  ('🪞', 'خزانة'),
  ('🛏️', 'غرفة نوم'),
  ('🍽️', 'مطبخ'),
  ('🪑', 'كرسي'),
  ('🛋️', 'أريكة'),
  ('📦', 'رف/وحدة'),
  ('🖼️', 'ديكور خشبي'),
  ('⚙️', 'أخرى'),
];

const _outputTypes = [
  ('📋', 'قائمة القطع'),
  ('📐', 'جدول القياسات'),
  ('🌲', 'قائمة المواد'),
  ('🔧', 'خطوات التجميع'),
  ('🔩', 'الأدوات المطلوبة'),
  ('💰', 'تقدير التكلفة'),
  ('✨', 'نصائح التشطيب'),
  ('⏱️', 'وقت الإنتاج'),
];

class AIAnalyzerScreen extends ConsumerStatefulWidget {
  const AIAnalyzerScreen({super.key});

  @override
  ConsumerState<AIAnalyzerScreen> createState() => _AIAnalyzerScreenState();
}

class _AIAnalyzerScreenState extends ConsumerState<AIAnalyzerScreen> {
  final _textController = TextEditingController();
  final _apiKeyController = TextEditingController();
  String? _apiKey;
  String _selectedProduct = '';
  final Set<String> _selectedOutputs = {'قائمة القطع', 'جدول القياسات', 'قائمة المواد'};
  File? _selectedImage;
  String _inputMode = 'text'; // 'text' | 'image' | 'both'
  String _material = 'خشب MDF';
  String _result = '';
  bool _isLoading = false;

  final _picker = ImagePicker();

  @override
  void dispose() {
    _textController.dispose();
    _apiKeyController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final img = await _picker.pickImage(source: ImageSource.gallery);
    if (img != null) {
      setState(() => _selectedImage = File(img.path));
    }
  }

  Future<void> _analyze() async {
    if (_apiKey == null || _apiKey!.isEmpty) {
      _showApiKeyDialog();
      return;
    }

    if (_textController.text.trim().isEmpty && _selectedImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('⚠️ أدخل نصاً أو اختر صورة')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _result = '';
    });

    try {
      final prompt = _buildPrompt();
      final response = await _callAPI(prompt);
      setState(() => _result = response);
    } catch (e) {
      setState(() => _result = '❌ خطأ: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  String _buildPrompt() {
    final outputs = _selectedOutputs.join('، ');
    final product = _selectedProduct.isEmpty ? 'منتج نجارة' : _selectedProduct;
    final userText = _textController.text.trim();

    return '''أنت خبير نجارة محترف. قم بتحليل ${userText.isNotEmpty ? 'الوصف التالي' : 'الصورة المرفقة'} لـ $product وأنشئ:
$outputs

المواد المطلوبة: $_material
${userText.isNotEmpty ? 'الوصف: $userText' : ''}

قدم المخرجات بشكل منظم وواضح باللغة العربية. استخدم جداول ونقاط منظمة.''';
  }

  Future<String> _callAPI(String prompt) async {
    final messages = <Map<String, dynamic>>[];

    if (_selectedImage != null && (_inputMode == 'image' || _inputMode == 'both')) {
      final bytes = await _selectedImage!.readAsBytes();
      final b64 = base64Encode(bytes);
      messages.add({
        'role': 'user',
        'content': [
          {
            'type': 'image',
            'source': {
              'type': 'base64',
              'media_type': 'image/jpeg',
              'data': b64,
            }
          },
          {'type': 'text', 'text': prompt}
        ]
      });
    } else {
      messages.add({'role': 'user', 'content': prompt});
    }

    final resp = await http.post(
      Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey!,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': 'claude-sonnet-4-20250514',
        'max_tokens': 2000,
        'messages': messages,
      }),
    );

    if (resp.statusCode != 200) {
      throw Exception('API Error ${resp.statusCode}: ${resp.body}');
    }

    final data = jsonDecode(resp.body);
    return data['content'][0]['text'] as String;
  }

  void _showApiKeyDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('⚙️ إعداد API Key'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'أدخل مفتاح Anthropic API الخاص بك لاستخدام محلل الذكاء الاصطناعي',
              style: TextStyle(fontFamily: 'Cairo', fontSize: 13),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _apiKeyController,
              decoration: const InputDecoration(
                hintText: 'sk-ant-...',
                labelText: 'API Key',
              ),
              obscureText: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() => _apiKey = _apiKeyController.text.trim());
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('محلل AI 🤖'),
        actions: [
          IconButton(
            icon: const Icon(Icons.key_outlined),
            onPressed: _showApiKeyDialog,
            tooltip: 'إعداد API Key',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header card
            AppCard(
              color: AppColors.tealLight,
              child: Row(
                children: [
                  const Text('🤖', style: TextStyle(fontSize: 36)),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('محلل النجارة الذكي', style: AppTextStyles.title),
                        Text(
                          'صف مشروعك أو ارفع صورة وسيتولى الذكاء الاصطناعي التحليل',
                          style: AppTextStyles.caption,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: AppSpacing.lg),

            // ── Product Type ──
            Text('نوع المنتج', style: AppTextStyles.label),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _productTypes.map((t) {
                final isSelected = _selectedProduct == t.$2;
                return GestureDetector(
                  onTap: () => setState(() => _selectedProduct = isSelected ? '' : t.$2),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.primary : AppColors.surface,
                      borderRadius: AppRadius.small,
                      border: Border.all(
                        color: isSelected ? AppColors.primary : AppColors.border,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(t.$1, style: const TextStyle(fontSize: 14)),
                        const SizedBox(width: 4),
                        Text(
                          t.$2,
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isSelected ? Colors.white : AppColors.text,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: AppSpacing.lg),

            // ── Input Mode ──
            Text('طريقة الإدخال', style: AppTextStyles.label),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: [
                _ModeBtn(label: '✏️ نص', value: 'text', selected: _inputMode, onTap: (v) => setState(() => _inputMode = v)),
                const SizedBox(width: 8),
                _ModeBtn(label: '🖼️ صورة', value: 'image', selected: _inputMode, onTap: (v) => setState(() => _inputMode = v)),
                const SizedBox(width: 8),
                _ModeBtn(label: '✏️+🖼️ كلاهما', value: 'both', selected: _inputMode, onTap: (v) => setState(() => _inputMode = v)),
              ],
            ),

            const SizedBox(height: AppSpacing.lg),

            // ── Text Input ──
            if (_inputMode == 'text' || _inputMode == 'both') ...[
              Text('وصف المشروع', style: AppTextStyles.label),
              const SizedBox(height: AppSpacing.sm),
              TextField(
                controller: _textController,
                maxLines: 4,
                style: AppTextStyles.body,
                decoration: const InputDecoration(
                  hintText: 'مثال: باب غرفة نوم بمقاس 210×90 سم، خشب MDF، بمفصلات مخفية...',
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
            ],

            // ── Image Input ──
            if (_inputMode == 'image' || _inputMode == 'both') ...[
              Text('صورة المنتج', style: AppTextStyles.label),
              const SizedBox(height: AppSpacing.sm),
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 140,
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: AppRadius.medium,
                    border: Border.all(
                      color: _selectedImage != null ? AppColors.primary : AppColors.border,
                      style: BorderStyle.solid,
                    ),
                  ),
                  child: _selectedImage != null
                      ? ClipRRect(
                          borderRadius: AppRadius.medium,
                          child: Image.file(_selectedImage!, fit: BoxFit.cover, width: double.infinity),
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('🖼️', style: TextStyle(fontSize: 32)),
                            const SizedBox(height: 8),
                            Text('اضغط لاختيار صورة', style: AppTextStyles.caption),
                          ],
                        ),
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
            ],

            // ── Material ──
            Text('نوع الخشب / المادة', style: AppTextStyles.label),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['خشب MDF', 'خشب طبيعي', 'رقائق خشبية', 'ألمنيوم', 'زجاج', 'مختلط'].map((m) {
                final sel = _material == m;
                return GestureDetector(
                  onTap: () => setState(() => _material = m),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.tealLight : AppColors.surface,
                      borderRadius: AppRadius.small,
                      border: Border.all(color: sel ? AppColors.primary : AppColors.border),
                    ),
                    child: Text(
                      m,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: sel ? AppColors.primary : AppColors.text,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: AppSpacing.lg),

            // ── Output Types ──
            Text('نوع المخرجات المطلوبة', style: AppTextStyles.label),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _outputTypes.map((o) {
                final sel = _selectedOutputs.contains(o.$2);
                return GestureDetector(
                  onTap: () => setState(() {
                    if (sel) {
                      _selectedOutputs.remove(o.$2);
                    } else {
                      _selectedOutputs.add(o.$2);
                    }
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.primary : AppColors.surface,
                      borderRadius: AppRadius.small,
                      border: Border.all(color: sel ? AppColors.primary : AppColors.border),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(o.$1, style: const TextStyle(fontSize: 12)),
                        const SizedBox(width: 4),
                        Text(
                          o.$2,
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: sel ? Colors.white : AppColors.text,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: AppSpacing.xl),

            // ── Analyze Button ──
            PrimaryButton(
              label: 'تحليل المشروع',
              icon: '🔍',
              onTap: _analyze,
              isLoading: _isLoading,
              color: AppColors.purple,
            ),

            // ── Result ──
            if (_result.isNotEmpty) ...[
              const SizedBox(height: AppSpacing.xl),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: AppRadius.medium,
                  border: Border.all(color: AppColors.primary.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('✅', style: TextStyle(fontSize: 18)),
                        const SizedBox(width: 8),
                        Text('نتيجة التحليل', style: AppTextStyles.title),
                      ],
                    ),
                    const Divider(height: 16),
                    Text(
                      _result,
                      style: AppTextStyles.body.copyWith(height: 1.7),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }
}

class _ModeBtn extends StatelessWidget {
  final String label;
  final String value;
  final String selected;
  final ValueChanged<String> onTap;

  const _ModeBtn({
    required this.label,
    required this.value,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = selected == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => onTap(value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primary : AppColors.surface,
            borderRadius: AppRadius.small,
            border: Border.all(color: isSelected ? AppColors.primary : AppColors.border),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: isSelected ? Colors.white : AppColors.text,
            ),
          ),
        ),
      ),
    );
  }
}
