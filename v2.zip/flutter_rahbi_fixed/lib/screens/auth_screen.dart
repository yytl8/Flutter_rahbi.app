import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../widgets/common_widgets.dart';

class AuthScreen extends ConsumerStatefulWidget {
  const AuthScreen({super.key});

  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Login controllers
  final _loginEmail = TextEditingController();
  final _loginPassword = TextEditingController();
  final _loginFormKey = GlobalKey<FormState>();

  // Register controllers
  final _regName = TextEditingController();
  final _regEmail = TextEditingController();
  final _regPhone = TextEditingController();
  final _regShop = TextEditingController();
  final _regPassword = TextEditingController();
  final _regFormKey = GlobalKey<FormState>();

  bool _loginObscure = true;
  bool _regObscure = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _loginEmail.dispose();
    _loginPassword.dispose();
    _regName.dispose();
    _regEmail.dispose();
    _regPhone.dispose();
    _regShop.dispose();
    _regPassword.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_loginFormKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    final error = await ref.read(authProvider.notifier).login(
          _loginEmail.text,
          _loginPassword.text,
        );
    if (mounted) {
      setState(() => _isLoading = false);
      if (error != null) _showError(error);
    }
  }

  Future<void> _register() async {
    if (!_regFormKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    final error = await ref.read(authProvider.notifier).register(
          name: _regName.text,
          email: _regEmail.text,
          password: _regPassword.text,
          shopName: _regShop.text,
          phone: _regPhone.text.isEmpty ? null : _regPhone.text,
        );
    if (mounted) {
      setState(() => _isLoading = false);
      if (error != null) _showError(error);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            children: [
              const SizedBox(height: 24),
              // Logo
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.primary, AppColors.primary2],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.4),
                      blurRadius: 28,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Center(
                  child: Text('🪵', style: TextStyle(fontSize: 38)),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'الرحبي للنجارة',
                style: AppTextStyles.headline1,
              ),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Expanded(child: Divider(endIndent: 12)),
                  Text('نظام إدارة المحلات', style: AppTextStyles.caption),
                  const Expanded(child: Divider(indent: 12)),
                ],
              ),
              const SizedBox(height: 28),

              // Card
              Container(
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: AppRadius.large,
                  border: Border.all(color: AppColors.border),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.08),
                      blurRadius: 32,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Tabs
                    Container(
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(color: AppColors.border),
                        ),
                      ),
                      child: TabBar(
                        controller: _tabController,
                        tabs: const [
                          Tab(text: '🔑 تسجيل الدخول'),
                          Tab(text: '🆕 إنشاء حساب'),
                        ],
                      ),
                    ),

                    // Tab content
                    SizedBox(
                      height: _tabController.index == 0 ? 320 : 480,
                      child: TabBarView(
                        controller: _tabController,
                        children: [
                          _buildLoginForm(),
                          _buildRegisterForm(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoginForm() {
    return Padding(
      padding: const EdgeInsets.all(AppSpacing.xl),
      child: Form(
        key: _loginFormKey,
        child: Column(
          children: [
            const SizedBox(height: 8),
            AppFormField(
              label: 'البريد الإلكتروني',
              hint: 'admin@example.com',
              controller: _loginEmail,
              keyboardType: TextInputType.emailAddress,
              validator: (v) =>
                  v?.isEmpty == true ? 'أدخل البريد الإلكتروني' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'كلمة المرور',
              hint: '••••••••',
              controller: _loginPassword,
              obscureText: _loginObscure,
              validator: (v) =>
                  v?.isEmpty == true ? 'أدخل كلمة المرور' : null,
              suffix: IconButton(
                icon: Icon(
                  _loginObscure ? Icons.visibility_off : Icons.visibility,
                  color: AppColors.text3,
                  size: 20,
                ),
                onPressed: () => setState(() => _loginObscure = !_loginObscure),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            PrimaryButton(
              label: 'دخول',
              icon: '🔑',
              onTap: _login,
              isLoading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRegisterForm() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSpacing.xl),
      child: Form(
        key: _regFormKey,
        child: Column(
          children: [
            const SizedBox(height: 4),
            AppFormField(
              label: 'اسم المحل',
              hint: 'الرحبي للنجارة',
              controller: _regShop,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'اسمك الكامل',
              hint: 'عبدالله الرحبي',
              controller: _regName,
              validator: (v) => v?.isEmpty == true ? 'مطلوب' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'البريد الإلكتروني',
              hint: 'admin@example.com',
              controller: _regEmail,
              keyboardType: TextInputType.emailAddress,
              validator: (v) =>
                  v?.isEmpty == true ? 'أدخل البريد الإلكتروني' : null,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'رقم الهاتف (اختياري)',
              hint: '05xxxxxxxx',
              controller: _regPhone,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: AppSpacing.md),
            AppFormField(
              label: 'كلمة المرور',
              hint: '••••••••',
              controller: _regPassword,
              obscureText: _regObscure,
              validator: (v) =>
                  (v?.length ?? 0) < 6 ? 'على الأقل 6 أحرف' : null,
              suffix: IconButton(
                icon: Icon(
                  _regObscure ? Icons.visibility_off : Icons.visibility,
                  color: AppColors.text3,
                  size: 20,
                ),
                onPressed: () => setState(() => _regObscure = !_regObscure),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            PrimaryButton(
              label: 'إنشاء الحساب',
              icon: '🆕',
              onTap: _register,
              isLoading: _isLoading,
            ),
          ],
        ),
      ),
    );
  }
}
